#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <string.h>


typedef struct No {
    double dado;
    struct No *proximo;
} No;

typedef struct {
    No *topo;
} Pilha;


void inicializar(Pilha *pilha) {
    pilha->topo = NULL;
}


void empilhar(Pilha *pilha, double valor) {
    No *novoNo = (No *)malloc(sizeof(No));
    if (novoNo == NULL) {
        printf("Erro: Falha na aloca��o de mem�ria\n");
        exit(EXIT_FAILURE);
    }
    novoNo->dado = valor;
    novoNo->proximo = pilha->topo;
    pilha->topo = novoNo;
}


double desempilhar(Pilha *pilha) {
    if (pilha->topo != NULL) {
        No *temp = pilha->topo;
        double valor = temp->dado;
        pilha->topo = temp->proximo;
        free(temp);
        return valor;
    } else {
        printf("Erro: Pilha vazia\n");
        exit(EXIT_FAILURE);
    }
}


double avaliarOperacao(double operando1, double operando2, char operador) {
    switch (operador) {
    case '+':
        return operando1 + operando2;
    case '-':
        return operando1 - operando2;
    case '*':
        return operando1 * operando2;
    case '/':
        if (operando2 != 0.0) {
            return operando1 / operando2;
        } else {
            printf("Erro: Divis�o por zero\n");
            exit(EXIT_FAILURE);
        }
    case '^':
        return pow(operando1, operando2);
    default:
        printf("Erro: Operador inv�lido\n");
        exit(EXIT_FAILURE);
    }
}


void traduzirPosfixaParaPrefixa(const char *expressao_posfixa, char *expressao_prefixa) {
    Pilha pilha;
    inicializar(&pilha);

    int j = 0;
    for (int i = 0; expressao_posfixa[i] != '\0'; ++i) {
        if (isdigit(expressao_posfixa[i]) || (expressao_posfixa[i] == '.' && isdigit(expressao_posfixa[i + 1]))) {
       
            while (isdigit(expressao_posfixa[i]) || expressao_posfixa[i] == '.') {
                expressao_prefixa[j++] = expressao_posfixa[i++];
            }
            --i; 
        } else if (isspace(expressao_posfixa[i])) {
            
            continue;
        } else {
            
            double operando2 = desempilhar(&pilha);
            double operando1 = desempilhar(&pilha);

            
            expressao_prefixa[j++] = expressao_posfixa[i];

            
            j += sprintf(&expressao_prefixa[j], "%.2f %.2f", operando1, operando2);

           
            empilhar(&pilha, avaliarOperacao(operando1, operando2, expressao_posfixa[i]));
        }
    }

    
    expressao_prefixa[j] = '\0';
}


double avaliarExpressaoPosfixada(const char *expressao) {
    Pilha pilha;
    inicializar(&pilha);

    for (int i = 0; expressao[i] != '\0'; ++i) {
        if (isdigit(expressao[i]) || (expressao[i] == '.' && isdigit(expressao[i + 1]))) {
            
            empilhar(&pilha, strtod(&expressao[i], NULL));
            
            while (isdigit(expressao[i]) || expressao[i] == '.') {
                ++i;
            }
            --i; 
        } else if (isspace(expressao[i])) {
            
            continue;
        } else if (isalpha(expressao[i])) {
            
            char operacao[4];
            int j = 0;
            while (isalpha(expressao[i])) {
                operacao[j++] = expressao[i++];
            }
            operacao[j] = '\0';

            double operando = desempilhar(&pilha);

            if (strcmp(operacao, "log") == 0) {
                empilhar(&pilha, log10(operando));
            } else if (strcmp(operacao, "sen") == 0) {
                empilhar(&pilha, sin(operando));
            } else if (strcmp(operacao, "cos") == 0) {
                empilhar(&pilha, cos(operando));
            } else if (strcmp(operacao, "tan") == 0) {
                empilhar(&pilha, tan(operando));
            } else {
                printf("Erro: Opera��o n�o reconhecida\n");
                exit(EXIT_FAILURE);
            }

            
            --i;
        } else {
            
            double operando2 = desempilhar(&pilha);
            double operando1 = desempilhar(&pilha);
            empilhar(&pilha, avaliarOperacao(operando1, operando2, expressao[i]));
        }
    }

    
    return desempilhar(&pilha);
}

int main() {
    
    const char *expressao = "3 4 + 5 *";
    double resultado = avaliarExpressaoPosfixada(expressao);
    printf("Resultado: %.2f\n", resultado);

    
    char expressao_prefixa[100];
    traduzirPosfixaParaPrefixa(expressao, expressao_prefixa);
    printf("Nota��o Pr�-fixada: %s\n", expressao_prefixa);

    return 0;
}

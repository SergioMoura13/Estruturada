#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>


typedef struct No {
    double dado;
    struct No *proximo;
} No;

typedef struct {
    No *topo;
} Pilha;


void inicializar(Pilha *pilha) {
    pilha->topo = NULL;
}


void empilhar(Pilha *pilha, double valor) {
    No *novoNo = (No *)malloc(sizeof(No));
    if (novoNo == NULL) {
        printf("Erro: Falha na alocação de memória\n");
        exit(EXIT_FAILURE);
    }
    novoNo->dado = valor;
    novoNo->proximo = pilha->topo;
    pilha->topo = novoNo;
}


double desempilhar(Pilha *pilha) {
    if (pilha->topo != NULL) {
        No *temp = pilha->topo;
        double valor = temp->dado;
        pilha->topo = temp->proximo;
        free(temp);
        return valor;
    } else {
        printf("Erro: Pilha vazia\n");
        exit(EXIT_FAILURE);
    }
}


double avaliarOperacao(char operador, double operando1, double operando2) {
    switch (operador) {
        case '+':
            return operando1 + operando2;
        case '-':
            return operando1 - operando2;
        case '*':
            return operando1 * operando2;
        case '/':
            if (operando2 != 0.0) {
                return operando1 / operando2;
            } else {
                printf("Erro: Divisão por zero\n");
                exit(EXIT_FAILURE);
            }
        case '^':
            return pow(operando1, operando2);
        case 'l':
            return log10(operando1);
        case 's':
            return sin(operando1);
        case 'c':
            return cos(operando1);
        case 't':
            return tan(operando1);
        default:
            printf("Erro: Operador inválido\n");
            exit(EXIT_FAILURE);
    }
}


void inverterString(char *str) {
    int inicio = 0;
    int fim = strlen(str) - 1;
    while (inicio < fim) {
        char temp = str[inicio];
        str[inicio] = str[fim];
        str[fim] = temp;
        inicio++;
        fim--;
    }
}


void traduzirParaPrefixo(const char *expressaoPosfixa, char *expressaoPrefixa) {
    Pilha pilha;
    inicializar(&pilha);

    for (int i = 0; expressaoPosfixa[i] != '\0'; ++i) {
        if (isdigit(expressaoPosfixa[i])) {
            
            int j = 0;
            while (isdigit(expressaoPosfixa[i + j])) {
                expressaoPrefixa[j] = expressaoPosfixa[i + j];
                j++;
            }
            expressaoPrefixa[j] = ' ';
            i += j - 1;
        } else if (expressaoPosfixa[i] == ' ' || expressaoPosfixa[i] == '\t') {
           
            continue;
        } else if (expressaoPosfixa[i] == 'l' || expressaoPosfixa[i] == 's' || expressaoPosfixa[i] == 'c' || expressaoPosfixa[i] == 't') {
           
            double operando = desempilhar(&pilha);
            empilhar(&pilha, avaliarOperacao(expressaoPosfixa[i], operando, 0.0));
        } else {
            
            empilhar(&pilha, expressaoPosfixa[i]);
        }
    }

    
    int pos = 0;
    while (pilha.topo != NULL) {
        expressaoPrefixa[pos++] = desempilhar(&pilha);
        expressaoPrefixa[pos++] = ' ';
    }

   
    expressaoPrefixa[pos] = '\0';

    
    inverterString(expressaoPrefixa);
}

int main() {
    
    const char *expressaoPosfixa1 = "3 4 + 5*";
    char expressaoPrefixa1[100];

    double resultado1 = avaliarExpressaoPosfixada(expressaoPosfixa1);
    printf("Teste 1 - Resultado: %.6f\n", resultado1);

    traduzirParaPrefixo(expressaoPosfixa1, expressaoPrefixa1);
    printf("Expressão pré-fixada correspondente: %s\n\n", expressaoPrefixa1);

    
    const char *expressaoPosfixa2 = "7 2 * 4 +";
    char expressaoPrefixa2[100];

    double resultado2 = avaliarExpressaoPosfixada(expressaoPosfixa2);
    printf("Teste 2 - Resultado: %.6f\n", resultado2);

    traduzirParaPrefixo(expressaoPosfixa2, expressaoPrefixa2);
    printf("Expressão pré-fixada correspondente: %s\n\n", expressaoPrefixa2);

   
    const char *expressaoPosfixa3 = "8 5 2 4 + * +";
    char expressaoPrefixa3[100];

    double resultado3 = avaliarExpressaoPosfixada(expressaoPosfixa3);
    printf("Teste 3 - Resultado: %.6f\n", resultado3);

    traduzirParaPrefixo(expressaoPosfixa3, expressaoPrefixa3);
    printf("Expressão pré-fixada correspondente: %s\n\n", expressaoPrefixa3);

    return 0;
}

